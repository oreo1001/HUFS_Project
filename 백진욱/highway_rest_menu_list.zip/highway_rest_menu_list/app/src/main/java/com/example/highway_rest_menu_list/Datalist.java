package com.example.highway_rest_menu_list;

public class Datalist {
    String mName;
    String mNumber;
    String mDepartment;
}
