package com.example.project;

public class Datalist {
    String mName;
    String mNumber;
    String mDepartment;
}
